$(document).ready(function(){


    var ww = $(window).width();
    if (ww > 500){
        $("#navbarDropdown1").hover(function(){
        $(".dropdown-menu").toggleClass("show"); });
    }else{
        $("#navbarDropdown1").click(function(){
        $(".dropdown-menu").toggleClass("show");
         });

    }


    $(".navbar-toggler").click(function(){
        $(".navbar-toggler").toggleClass("open");
        $(".navbar-collapse").toggleClass("show");
        });

});
